numero1 = int(input('Digite um número inteiro: '))
numero2 = int(input('Digite o segundo número inteiro: '))
numero3 = float(input('Digite um número real: '))

dobro = numero1*numero1
metade = numero2/2
print('O valor do dobro do primeiro número com metade do segundo número: ', dobro+metade)

print('A soma do triplo do primeiro com o tercerio é: ', numero1*3 + numero3)

print('O terceiro número elevado ao cubo: ', numero3**3)