numero1 = int(input('Digite um número: '))
numero2 = int(input('Digite o segundo número: '))

if numero1 % 2 == 0:
    print(f'O número {numero1} é par')
else:
    print(f'O número {numero2} é ímpar')