numero1 = float(5.2)
numero2 = float(7.5)

print('Um número com decimais: ', numero1)
print('Segundo número com decimais: ', numero2)

print(' ')
result_soma = float(input('Diga o resultado da operação de soma das duas: '))
if result_soma == 12.7:
    print('O resultado está correto. ')
else:
    print('Resultado incompatível. ')
print('')

result_sub = float(input('Diga o resultado da operação de subtração das duas: '))
if result_sub == 2.3:
    print('O Resultado está correto. ')
else:
    print('Resultado incompatível. ')
    print('')

result_multi = float(input('Diga o resultado da operação de multiplicação: '))
if result_multi == 39:
    print('O Resultado está correto. ')
else:
    print('Resultado incompatível. ')
    print('')

result_div = float(input('Diga o resultado da operação da divisão: '))
if result_div == 1.44:
    print('O resultado está correto. ')
else:
    print('Resultado incompatível. ')
    print('')