numero1 = int(input('Digite um número: '))
numero2 = int(input('Digite o segundo número: '))
if numero1 > numero2:
    print(f'O número {numero1}, é maior que {numero2}')
else:
    print(f'O número {numero2} é menor que {numero1}')
